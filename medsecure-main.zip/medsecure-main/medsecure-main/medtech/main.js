document.addEventListener('DOMContentLoaded', function() {
    var btnContinuar = document.getElementById('btn-continuar');
    var categoriaSection = document.getElementById('categoria-section');

    btnContinuar.addEventListener('click', function() {
        categoriaSection.style.display = 'block';
    });
});
